# Sinal — com QR dinâmico (editável depois de impresso)

Esta versão adiciona QR codes que você pode editar depois de já ter impresso —
o QR aponta pra um endereço seu (`seusite.netlify.app/r/CODIGO`), que
redireciona pra onde você configurar. Vale pra Link, WhatsApp e Instagram.
Pix continua sempre estático (não é um link, é lido direto pelo app do banco).

## Isso muda a forma de publicar

Como agora tem funções rodando no servidor (não é só HTML puro), **não dá mais
pra simplesmente arrastar a pasta no Netlify Drop**. O caminho passa a ser via
GitHub. Ainda assim continua tudo grátis.

## Passo a passo completo

### 1. Subir pro GitHub
1. Crie um repositório novo no GitHub (pode ser privado).
2. Suba todos os arquivos desta pasta (`index.html`, `favicon.svg`,
   `netlify.toml`, `package.json`, e a pasta `netlify/functions/`).

### 2. Conectar no Netlify
1. Entre em [app.netlify.com](https://app.netlify.com) e clique em
   **Add new site > Import an existing project**.
2. Escolha **GitHub** e selecione o repositório.
3. Nas configurações de build, deixe como está — o `netlify.toml` já diz pro
   Netlify onde estão as funções e as rotas. Não precisa de build command.
4. Clique em **Deploy**.

### 3. Configurar sua senha de edição
Antes (ou logo depois) do primeiro deploy:
1. No painel do site, vá em **Site configuration > Environment variables**.
2. Clique em **Add a variable**.
3. Nome: `SINAL_EDIT_PASSWORD`
4. Valor: escolha uma senha só sua (essa é a senha que você vai digitar toda
   vez que criar ou editar um QR dinâmico).
5. Salve e, se o site já tinha feito deploy antes de você configurar a
   variável, clique em **Trigger deploy** pra ela valer.

### 4. Testar
1. Abra o link do seu site (`algumacoisa.netlify.app`).
2. Escolha um tipo (Link, WhatsApp ou Instagram), marque
   **"Tornar este QR editável"**, digite a senha que você configurou, e gere.
3. Vai aparecer um código (ex: `qe9MM7w`) — guarde ele.
4. Escaneie o QR: deve te redirecionar pro destino certo.
5. Vá até a seção **"Editar um QR dinâmico"**, cole o código, um novo
   destino e a mesma senha, clique em **Atualizar destino**.
6. Escaneie o mesmo QR de novo (já impresso, sem mexer nele) — agora deve ir
   pro novo destino.

## Sobre os dados

Os destinos dos QRs dinâmicos ficam guardados no **Netlify Blobs**, um banco
de dados simples que já vem incluído no plano grátis do Netlify — não precisa
configurar nada além da senha.

## Segurança

A senha de edição é única e vale pra todos os QRs dinâmicos que você criar —
qualquer pessoa que souber a senha pode editar qualquer código. Isso é
suficiente pra uso pessoal ou de uma pequena equipe de confiança. Se um dia
precisar que cada QR tenha dono separado (ex: vários lojistas usando o mesmo
site, cada um só editando o seu), dá pra evoluir pra senha por código — me
chama quando chegar nessa necessidade.
